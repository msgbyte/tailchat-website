"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
exports.checkUpdates = void 0;
var electron_1 = require("electron");
var electron_update_notifier_1 = require("electron-update-notifier");
var update_electron_app_1 = __importDefault(require("update-electron-app"));
var electron_log_1 = __importDefault(require("electron-log"));
var repo = 'msgbyte/tailchat';
electron_1.app.whenReady().then(function () {
    switch (process.platform) {
        // case 'darwin': // NOTICE: require codesign
        case 'win32':
            (0, update_electron_app_1["default"])({
                repo: repo,
                logger: electron_log_1["default"]
            });
            break;
        default:
            (0, electron_update_notifier_1.setUpdateNotification)({
                repository: repo,
                silent: true
            });
    }
});
/**
 * 手动检查更新
 */
function checkUpdates() {
    return (0, electron_update_notifier_1.checkForUpdates)({
        repository: repo,
        silent: false
    });
}
exports.checkUpdates = checkUpdates;
//# sourceMappingURL=update.js.map