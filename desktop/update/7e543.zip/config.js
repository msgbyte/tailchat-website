"use strict";
exports.__esModule = true;
exports.config = void 0;
var electron_1 = require("electron");
var isDev = !electron_1.app.isPackaged;
var webUrl = isDev
    ? 'http://localhost:11011'
    : 'https://nightly.paw.msgbyte.com';
exports.config = {
    isDev: isDev,
    webUrl: webUrl
};
//# sourceMappingURL=config.js.map